for ip1 in $(ip a s |grep inet |grep -v 127.0.0.1 |grep -v inet6 |awk '{print $2}'|cut -d  "/" -f1|sed -n '1p')
do
echo ${ip1}
done

for ip2 in $(cat /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml |grep DhcpStaticIp |cut -d "<" -f2 |cut -d ">" -f2)
do
echo ${ip2}
done

sed -i "s/$ip2/$ip1/g" /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml

for now_ip in $(cat /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml |grep DhcpStaticIp |cut -d "<" -f2 |cut -d ">" -f2)
do
if [ $ip1 == $now_ip ]
then
echo "ip has been changed"
fi
done

read -p "please input PCB username:" name1
read -p "please input PCB password:" passwd1
for name2 in $(cat /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml |grep UserName |cut -d "<" -f2 |cut -d ">" -f2)
do
echo $name2
done

sed -i "s/$name2/$name1/g" /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml
for now_name in $(cat /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml |grep UserName |cut -d "<" -f2 |cut -d ">" -f2)
do
if [ $now_name == $name1 ]
then
echo "username has been changed"
fi
done


for passwd2 in $(cat /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml |grep RootPasswd |cut -d "<" -f2 |cut -d ">" -f2)
do
echo $passwd2
done

sed -i "s/$passwd2/$passwd1/g" /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml
for now_passwd in $(cat /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml |grep RootPasswd |cut -d "<" -f2 |cut -d ">" -f2)
do
if [ $now_passwd == $passwd1 ]
then
echo "password has been changed"
fi
done

read -p "pleasr input the PC_B ipaddr:" b_ip1
for b_ip2 in $(cat /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml |grep ReHost |cut -d "<" -f2 |cut -d ">" -f2)
do
echo ${ip2}
done
sed -i "s/$b_ip2/$b_ip1/g" /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml

for now_b_ip in $(cat /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml |grep ReHost |cut -d "<" -f2 |cut -d ">" -f2)
do
if [ $b_ip1 == $now_b_ip ]
then
echo "b_ip has been changed"
fi
done



read -p "pleasr input the PC_B HWaddr:" b_hwaddr1
for b_hwaddr2 in $(cat /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml |grep HWAddr |cut -d "<" -f2 |cut -d ">" -f2)
do
echo ${b_hwaddr1}
done
sed -i "s/$b_hwaddr2/$b_hwaddr1/" /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml

for now_b_hwaddr in $(cat /root/NS7-BVT-master-35978e33772e5fa28fbbcf177d79f3d2ee6371b6/ns7-bvt/testcases/Network_Service/config.xml |grep HWAddr |cut -d "<" -f2 |cut -d ">" -f2)
do
if [ $b_hwaddr1 == $now_b_hwaddr ]
then
echo "b_HWAddr has been changed"
fi
done


#判断rpm包是否存在
a=$(rpm -qa gcc expect rsh rsh-server xinetd tftp-server httpd tomcat ftp|wc -l)
if [ $a -ne 9 ]
then
yum -y install gcc expect rsh rsh-server xinetd tftp-server httpd tomcat ftp dhcp
fi
b=$(rpm -qa gcc expect rsh rsh-server xinetd tftp-server httpd tomcat ftp|wc -l)
if [ $b -eq 9 ]
then
echo "所有rpm包均已安装"
fi


#写入两台主机名字

hostnamectl set-hostname node1.test
hn=$(hostname)
a1=$(sed -n '$p' /etc/hosts)
b1=$(echo $a1 |grep "test")
if [[ $b1 != "" ]]
then
echo "ok"
sed -i '$d' /etc/hosts
fi
if [ $hn == "node1.test" ]
then
echo $ip1 $hn >> /etc/hosts
echo $b_ip1 "node2.test" >> /etc/hosts
fi

#关闭selinux
setenforce 0
sl=$(getenforce)
if [[ $sl == "Permissive" ]]
then
echo "selinux已经为Permissive"
fi

#关闭dhcpd服务
systemctl stop dhcpd
systemctl stop firewalld

./test1.sh
