#!/usr/bin/expect
spawn ssh 10.1.60.192
expect "*password:"
send "qwer1234\r"
expect "*]#"
send "setenforce 0\r"
send "systemctl stop firewalld\r"
send "yum -y install  expect rsh rsh-server xinetd tftp-server dhcp\r"
send "systemctl stop dhcpd\r"
send "sh test.sh\r"
send "logout\r"
expect "*]#"
interact



