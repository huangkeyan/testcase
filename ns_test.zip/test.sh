hostnamectl set-hostname node1.test
for ip1 in $(ip a s |grep inet |grep -v 127.0.0.1 |grep -v inet6 |awk '{print $2}'|cut -d  "/" -f1|sed -n '1p')
do
echo ${ip1}
done

hn=$(hostname)
a1=$(sed -n '$p' /etc/hosts)
b1=$(echo $a1 |grep "test")
if [[ $b1 != "" ]]
then
echo "ok"
sed -i '$d' /etc/hosts
fi
if [ $hn == "node1.test" ]
then
echo $ip1 $hn >> /etc/hosts
echo "10.1.60.192" "node2.test" >> /etc/hosts
fi

